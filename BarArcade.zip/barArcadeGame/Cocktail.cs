using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barArcadeGame
{
    internal class Cocktail
    {
        public Drink[] Drinks { get; set; }
    }

    public class Drink
    {
        public string StrDrink { get; set; }
    }
   
}
