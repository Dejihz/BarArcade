﻿
using var game = new barArcadeGame.Game1();
game.Run();
